import { SimpleEditor } from "@/components/tiptap-templates/simple/simple-editor"

export default function Page() {
  return <SimpleEditor />
}
